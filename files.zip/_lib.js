const {neon}=require("@neondatabase/serverless");
const SERVICES={"website-development":"Website Development","corporate-website":"Business / Corporate Website","ecommerce":"E-commerce Website","wordpress":"WordPress Development","shopify":"Shopify Development","website-redesign":"Website Redesign / Revamp","web-application":"Custom Web Application","landing-page":"Landing Page","maintenance":"Website Maintenance / Support","ai-automation":"AI Automation / AI Integration","optimization":"Website Performance / SEO / Optimization","other":"Other / Not Sure"};
const STATUSES=["new","contacted","in-progress","closed"];
const sql={query:(t,p)=>neon(process.env.DATABASE_URL).query(t,p)};
let init;
const ready=()=>init||(init=sql.query(`CREATE TABLE IF NOT EXISTS enquiries(id SERIAL PRIMARY KEY,name TEXT NOT NULL,email TEXT NOT NULL,phone TEXT,service TEXT NOT NULL,"serviceOtherDetails" TEXT,subject TEXT,message TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'new',"createdAt" TIMESTAMPTZ NOT NULL DEFAULT now())`).catch(e=>{init=null;throw e}));
const clean=(v,max)=>String(v??"").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,"").trim().slice(0,max);
module.exports={sql,ready,clean,SERVICES,STATUSES};

const nodemailer=require("nodemailer");
const {sql,ready,clean,SERVICES}=require("./_lib");
module.exports=async(req,res)=>{
  if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
  const b=req.body||{},d={name:clean(b.name,100),email:clean(b.email,150),phone:clean(b.phone,25),service:clean(b.service,40),subject:clean(b.subject,150),message:clean(b.message,5000),other:clean(b.serviceOtherDetails,500)};
  if(!d.name||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)||d.message.length<10||!d.subject)return res.status(400).json({error:"Please complete all required fields."});
  if(!SERVICES[d.service])return res.status(400).json({error:"Please select a service."});
  if(d.phone&&!/^\+?[\d\s()-]{7,18}$/.test(d.phone))return res.status(400).json({error:"Enter a valid phone number."});
  if(d.service!=="other")d.other="";
  try{
    await ready();
    await sql.query(`INSERT INTO enquiries(name,email,phone,service,"serviceOtherDetails",subject,message) VALUES($1,$2,$3,$4,$5,$6,$7)`,[d.name,d.email,d.phone,d.service,d.other,d.subject,d.message]);
  }catch(e){console.error(e);return res.status(500).json({error:"Could not save your message. Please try again."})}
  const {SMTP_HOST,SMTP_PORT=465,SMTP_USER,SMTP_PASS,NOTIFY_TO="tanishasharma928@gmail.com"}=process.env;
  if(SMTP_HOST&&SMTP_USER&&SMTP_PASS){
    const text=`NEW PORTFOLIO ENQUIRY\n\nName: ${d.name}\nEmail: ${d.email}\nPhone: ${d.phone||"—"}\n\nService:\n${SERVICES[d.service]}\n\n`+(d.other?`Other Requirements:\n${d.other}\n\n`:"")+`Subject:\n${d.subject}\n\nMessage:\n${d.message}\n`;
    try{await nodemailer.createTransport({host:SMTP_HOST,port:+SMTP_PORT,secure:+SMTP_PORT===465,auth:{user:SMTP_USER,pass:SMTP_PASS}}).sendMail({from:SMTP_USER,to:NOTIFY_TO,replyTo:d.email,subject:`New enquiry — ${SERVICES[d.service]}: ${d.subject}`.replace(/[\r\n]/g," "),text})}
    catch(e){console.error("Mail failed:",e.message)} // enquiry is already saved
  }
  res.json({ok:true});
};

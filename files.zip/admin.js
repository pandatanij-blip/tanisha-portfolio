const crypto=require("crypto");
const {sql,ready,clean,SERVICES,STATUSES}=require("./_lib");
const hash=s=>crypto.createHash("sha256").update(s).digest();
const eq=(a,b)=>crypto.timingSafeEqual(hash(a),hash(b));
module.exports=async(req,res)=>{
  const {ADMIN_USER="admin",ADMIN_PASS}=process.env;
  if(!ADMIN_PASS)return res.status(503).json({error:"Set ADMIN_PASS in Vercel environment variables."});
  const a=req.headers.authorization||"",[u,...p]=Buffer.from(a.slice(6),"base64").toString().split(":");
  if(!a.startsWith("Basic ")||!eq(u,ADMIN_USER)||!eq(p.join(":"),ADMIN_PASS)){res.setHeader("WWW-Authenticate",'Basic realm="Admin"');return res.status(401).json({error:"Authentication required"})}
  try{
    await ready();const q=req.query;
    if(q.meta)return res.json({services:SERVICES,statuses:STATUSES});
    if(q.id){
      const id=parseInt(q.id,10);if(!id)return res.status(400).json({error:"Bad id"});
      if(req.method==="PATCH"){
        if(!STATUSES.includes(req.body?.status))return res.status(400).json({error:"Invalid status"});
        await sql.query("UPDATE enquiries SET status=$1 WHERE id=$2",[req.body.status,id]);return res.json({ok:true});
      }
      const r=await sql.query("SELECT * FROM enquiries WHERE id=$1",[id]);
      return r[0]?res.json(r[0]):res.status(404).json({error:"Not found"});
    }
    const w=[],v=[],add=(c,x)=>{v.push(x);return c.replace("?","$"+v.length)};
    if(SERVICES[q.service])w.push(add("service=?",q.service));
    if(STATUSES.includes(q.status))w.push(add("status=?",q.status));
    const s=clean(q.q,80);
    if(s){v.push(`%${s}%`);const n="$"+v.length;w.push(`(name ILIKE ${n} OR email ILIKE ${n} OR subject ILIKE ${n} OR message ILIKE ${n} OR "serviceOtherDetails" ILIKE ${n})`)}
    res.json(await sql.query(`SELECT id,name,email,service,subject,status,"createdAt" FROM enquiries ${w.length?"WHERE "+w.join(" AND "):""} ORDER BY id DESC LIMIT 500`,v));
  }catch(e){console.error(e);res.status(500).json({error:"Server error"})}
};
